# coding=utf-8
import unittest
from common.config import *
from pages.baidu_homepage import Homepage
from selenium import webdriver
import HTMLTestRunner


class Test_search(unittest.TestCase):
    def setup(self):
        driver = webdriver.Firefox()
        self.driver = driver
        self.url = "https://www.baidu.com"
        text = 'yoyo'

    def tearndown(self):
        self.driver.quit()

    def test():
        home = Homepage()
        home.open(self.url)
        home.input_keys(text)
        home.submmit()


if '__name__' == __main__:
    HTMLTestRunner.main()
