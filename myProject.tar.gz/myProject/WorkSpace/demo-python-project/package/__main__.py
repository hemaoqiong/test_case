#!/usr/bin/python
# -*- coding: UTF-8 -*-

from package.app import main
main()
