#!/usr/bin/python
# -*- coding: UTF-8 -*-


def speak():
    print("This is foo1 speaking, I'm from pakcage.subpackage1")

if __name__ == "__main__":
    speak()