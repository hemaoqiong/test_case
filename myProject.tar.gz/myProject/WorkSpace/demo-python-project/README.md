#Overview
This is demo python projet.

It aims to demonstrate an elegant python project structure.

Also, this demo is used to show how to elegantly import packages within a project.

# Structure
*   data: where you store your project data
*   doc: where you store your project document
*   package: a demo python package