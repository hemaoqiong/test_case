import unittest
from public.pages import new_baidu


class Test_baidu(unittest.TestCase):
    def test_baidu():
        baidu = Baidu(self.dr)
        baidu.open()
        baidu.input_value('selenium')
        baidu.click_submit()
