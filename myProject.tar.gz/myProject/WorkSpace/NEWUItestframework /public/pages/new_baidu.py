# coding=utf-8
from public.common import pyselenium


class Baidu(PySelenium):
    url = 'http://www.daidu.com'
    input_id = id -> kw
    serch_id = id -> su

    def open(self):
        self.dr.open(url)

    def input_value(self, value):
        self.dr.clear_type(input_id, value)

    def click_submit(self):
        self.dr.click(serch_id)
