__author__ = 'kevin'

"""To store the way to connect sql server, sqlalchemy."""