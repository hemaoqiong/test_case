__author__ = 'kevin'

class Environment(object):
    UAT = "cllsuat"
    QA = "qa"
    STG  = "staging"
    LIVE = "www"

PROXY = ""
FIRE_PROFILE = ""

FIND_ELEMENT_TIMEOUT = 120
DEFAULT_SLEEP_TIME = 2
TIMEOUT = 120

