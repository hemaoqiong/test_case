__author__ = 'kevin'

class B2S(object):
    login_verification_accounts ={'LIVE':{'invalid_user':'1111', 'invalid_password':'22',\
                              'blank_user':'', 'blank_password':''}}
class BAI_DU(object):
    accounts =   {'UAT':{'username':'testbaidu@qp1.org', 'password':'1'}, \
                 'QA':{'username':'testbaidu@qp1.org', 'password':'1'}, \
                 'STG':{'username':'testbaidu@qp1.org', 'password':'1'}, \
                 'LIVE':{'username':'testbaidu@qp1.org', 'password':'1'}}
