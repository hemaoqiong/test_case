# automation_framework_demo
selenium for python automation framework design 

this demo is write for Chinese pelople who want to learn how to build a selenium automation framework, 
it scrpite languange is Python.


