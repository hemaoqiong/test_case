# coding=utf-8
import os
import time
print os.path.abspath('.')
# 设置报告文件保存路径
