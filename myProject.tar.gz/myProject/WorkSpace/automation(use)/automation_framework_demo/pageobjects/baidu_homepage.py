# coding=utf-8
from framework.base_page import BasePage


class HomePage(BasePage):
    # input_box = "id=>kw"
    # search_submit_btn = "xpath=>//*[@id='su']"
    # # 百度新闻入口
    # news_link = "xpath=>//*[@id='u1']/a[@name='tj_trnews']"

    # def type_search(self, text):
    #     self.type(self.input_box, text)

    # def send_submit_btn(self):
    #     self.click(self.search_submit_btn)

    # def click_news(self):
    #     self.click(self.news_link)
    #     self.sleep(2)

    # new

    input_loc = ("id", "kw")
    button_loc = ("id", "su")
    news_loc("xpath", "//div[@id='u_sp']/a[1]")
    # //*[@id="u_sp"]/a[1]

    def input(self, text):
        self.send_keys(input_loc, text)

    def submit(self):
        self.click(button_loc)

    def click_news(self):
        self.click(news_loc)
