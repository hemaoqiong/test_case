
import sys
sys.path.append(
    '/home/forin/WorkSpace/automation(use)/automation_framework_demo/framework')
sys.path.append(
    '/home/forin/WorkSpace/automation(use)/automation_framework_demo/pageobjects')

from framework.browser_engine import BrowserEngine
from pageobjects.baidu_homepage import HomePage
import unittest


class TestBaidu(unittest.TestCase):
    def setUp(self):
        driver = BrowserEngine()
        self.driver = driver
        self.driver.open_browser()

    def tearndown(self):
        self.driver.quit()
