#!/usr/bin/env python3
# -*- coding:utf-8 -*-

conn_dict = dict(host='127.0.0.1', user='root', passwd='root', db='test')
# 定义要链接的数据库
